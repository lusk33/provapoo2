module.exports = {
  singleQuote: true,
  trailingComma: 'all',
  allowParens: 'avoid',
};
