import { createGlobalStyle } from 'styled-components';

export default createGlobalStyle`

* {
  margin: 1%;
  padding: 20 px;
  outline: 2px;
  box-sizing: border-box;

}
table{
  width:100%;
  align: center;
}
tr{
  display: flex;
  size: 20px;
  flex-direction: row;
  outline: 2px;
  align: center;
  box-sizing: border-box;
  background-color: gray;
  color:white;
}
form {
  display: flex;
  flex-direction: column;
  outline: 2px;
  box-sizing:border-box;
}
body {
  -webkit-font-smoothing: antialiased;
  outline: 2px;
  margin: 20px;
}

body, input, button {
  font: 20px, arial;
  padding: 1%;
}

#root {
  max-width: 960px;
  margin: 0 auto;
  padding: 40px 20px;
}
span{
  padding: 3px;
  size: 20px;
  flex-direction: column;
  outline: 2px;
  background-color: gray;
  color:white;
}
button {
  cursor: pointer;
  display: flex;
  flex-direction: row;

}

`;
